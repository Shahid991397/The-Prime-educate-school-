import React from 'react';
import { Calendar, FileText, Users, CheckCircle, Clock, DollarSign } from 'lucide-react';

const Admissions = () => {
  const steps = [
    {
      icon: FileText,
      title: 'Submit Application',
      description: 'Complete our online application form with all required documents'
    },
    {
      icon: Users,
      title: 'School Visit',
      description: 'Schedule a campus tour and meet with our admissions team'
    },
    {
      icon: Calendar,
      title: 'Assessment',
      description: 'Participate in our age-appropriate assessment process'
    },
    {
      icon: CheckCircle,
      title: 'Enrollment',
      description: 'Receive admission decision and complete enrollment process'
    }
  ];

  const requirements = [
    'Completed application form',
    'Birth certificate',
    'Previous school records',
    'Immunization records',
    'Parent/guardian identification',
    'Emergency contact information'
  ];

  return (
    <section id="admissions" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Admissions</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join our school community and give your child the foundation for lifelong learning and success. Our admissions process is designed to be straightforward and welcoming.
          </p>
        </div>

        {/* Admission Process */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Admission Process</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => {
              const IconComponent = step.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-4 text-sm font-bold">
                    {index + 1}
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h4>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Requirements */}
          <div className="bg-gray-50 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Required Documents</h3>
            <div className="space-y-3">
              {requirements.map((requirement, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">{requirement}</span>
                </div>
              ))}
            </div>
            <div className="mt-8 p-4 bg-blue-100 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Clock className="h-5 w-5 text-blue-600" />
                <span className="font-semibold text-blue-900">Application Deadlines</span>
              </div>
              <p className="text-blue-800 text-sm">
                Fall Semester: May 31st | Spring Semester: November 30th
              </p>
            </div>
          </div>

          {/* Tuition & Fees */}
          <div className="bg-gray-50 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Tuition & Fees</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-b border-gray-200">
                <span className="text-gray-700">Elementary (K-5)</span>
                <span className="font-semibold text-gray-900">$8,500/year</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-gray-200">
                <span className="text-gray-700">Middle School (6-8)</span>
                <span className="font-semibold text-gray-900">$9,200/year</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-gray-200">
                <span className="text-gray-700">High School (9-12)</span>
                <span className="font-semibold text-gray-900">$10,500/year</span>
              </div>
              <div className="flex justify-between items-center py-3">
                <span className="text-gray-700">Registration Fee</span>
                <span className="font-semibold text-gray-900">$500</span>
              </div>
            </div>
            <div className="mt-6 p-4 bg-green-100 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span className="font-semibold text-green-900">Financial Aid Available</span>
              </div>
              <p className="text-green-800 text-sm">
                Need-based scholarships and payment plans available. Contact our office for details.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-8 text-white">
            <h3 className="text-3xl font-bold mb-4">Ready to Apply?</h3>
            <p className="text-xl mb-6">
              Take the first step towards your child's bright future. Our admissions team is here to help guide you through the process.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-yellow-500 hover:bg-yellow-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors">
                Start Application
              </button>
              <button className="border-2 border-white text-white hover:bg-white hover:text-blue-800 px-8 py-3 rounded-lg font-semibold transition-colors">
                Schedule Tour
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Admissions;