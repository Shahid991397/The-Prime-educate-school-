import React from 'react';
import { Target, Eye, Heart, CheckCircle } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">About Our School</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            For over two decades, The Prime Educate School has been committed to providing world-class education that nurtures intellectual curiosity, creativity, and character development.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <img 
              src="https://images.pexels.com/photos/1181424/pexels-photo-1181424.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Students in classroom"
              className="rounded-lg shadow-lg w-full h-96 object-cover"
            />
          </div>
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">Shaping Future Leaders</h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Our holistic approach to education combines academic excellence with character building, ensuring that every student develops not just intellectually, but also emotionally and socially. We believe in nurturing the unique potential of each child.
            </p>
            <div className="space-y-3">
              {[
                'Student-centered learning approach',
                'State-of-the-art facilities and technology',
                'Experienced and passionate faculty',
                'Comprehensive extracurricular programs'
              ].map((item, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Mission, Vision, Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-lg p-8 shadow-lg text-center hover:shadow-xl transition-shadow duration-300">
            <Target className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
            <p className="text-gray-600">
              To provide quality education that empowers students to become confident, creative, and responsible global citizens who contribute positively to society.
            </p>
          </div>
          <div className="bg-white rounded-lg p-8 shadow-lg text-center hover:shadow-xl transition-shadow duration-300">
            <Eye className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
            <p className="text-gray-600">
              To be a leading educational institution that inspires excellence, innovation, and integrity in every student we serve.
            </p>
          </div>
          <div className="bg-white rounded-lg p-8 shadow-lg text-center hover:shadow-xl transition-shadow duration-300">
            <Heart className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Values</h3>
            <p className="text-gray-600">
              Excellence, Integrity, Respect, Innovation, and Community - these core values guide everything we do and shape our school culture.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;