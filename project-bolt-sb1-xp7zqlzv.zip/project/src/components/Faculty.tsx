import React from 'react';
import { Award, BookOpen, Users } from 'lucide-react';

const Faculty = () => {
  const faculty = [
    {
      name: 'Dr. Sarah Johnson',
      role: 'Principal',
      image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=400',
      credentials: 'Ph.D. in Educational Leadership',
      experience: '20 years in education',
      specialization: 'Curriculum Development & School Administration'
    },
    {
      name: 'Prof. Michael Chen',
      role: 'Mathematics Department Head',
      image: 'https://images.pexels.com/photos/3184298/pexels-photo-3184298.jpeg?auto=compress&cs=tinysrgb&w=400',
      credentials: 'M.S. in Mathematics',
      experience: '15 years in teaching',
      specialization: 'Advanced Mathematics & STEM Education'
    },
    {
      name: 'Dr. Emily Rodriguez',
      role: 'Science Department Head',
      image: 'https://images.pexels.com/photos/3184306/pexels-photo-3184306.jpeg?auto=compress&cs=tinysrgb&w=400',
      credentials: 'Ph.D. in Biology',
      experience: '12 years in education',
      specialization: 'Research-Based Learning & Laboratory Sciences'
    },
    {
      name: 'Ms. Jennifer Adams',
      role: 'English Literature Teacher',
      image: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=400',
      credentials: 'M.A. in English Literature',
      experience: '10 years in teaching',
      specialization: 'Creative Writing & Literary Analysis'
    },
    {
      name: 'Mr. David Thompson',
      role: 'Arts & Music Coordinator',
      image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=400',
      credentials: 'M.F.A. in Visual Arts',
      experience: '8 years in education',
      specialization: 'Visual Arts & Music Performance'
    },
    {
      name: 'Ms. Lisa Wang',
      role: 'Student Counselor',
      image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=400',
      credentials: 'M.A. in School Counseling',
      experience: '14 years in counseling',
      specialization: 'Student Support & Career Guidance'
    }
  ];

  return (
    <section id="faculty" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Our Faculty</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Meet our dedicated team of experienced educators who are passionate about inspiring and guiding the next generation of leaders.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {faculty.map((member, index) => (
            <div key={index} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
              <img 
                src={member.image} 
                alt={member.name}
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h3>
                <p className="text-blue-600 font-semibold mb-3">{member.role}</p>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Award className="h-4 w-4 mr-2 text-yellow-500" />
                    {member.credentials}
                  </div>
                  <div className="flex items-center">
                    <BookOpen className="h-4 w-4 mr-2 text-green-500" />
                    {member.experience}
                  </div>
                  <div className="flex items-start">
                    <Users className="h-4 w-4 mr-2 text-blue-500 mt-0.5 flex-shrink-0" />
                    {member.specialization}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Faculty Stats */}
        <div className="bg-white rounded-lg p-8 shadow-lg">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-8">Faculty Excellence</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">50+</div>
              <div className="text-gray-600">Expert Teachers</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">85%</div>
              <div className="text-gray-600">Hold Advanced Degrees</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-600 mb-2">15</div>
              <div className="text-gray-600">Average Years Experience</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-600 mb-2">12:1</div>
              <div className="text-gray-600">Student-Teacher Ratio</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Faculty;