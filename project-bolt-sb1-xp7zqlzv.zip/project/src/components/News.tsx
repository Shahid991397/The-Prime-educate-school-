import React from 'react';
import { Calendar, ArrowRight } from 'lucide-react';

const News = () => {
  const news = [
    {
      date: '2024-01-15',
      title: 'Science Fair Winners Announced',
      excerpt: 'Congratulations to our students who excelled in this year\'s annual science fair with innovative projects ranging from renewable energy to biotechnology.',
      image: 'https://images.pexels.com/photos/256541/pexels-photo-256541.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'Academic Achievement'
    },
    {
      date: '2024-01-10',
      title: 'New STEM Laboratory Opening',
      excerpt: 'We\'re excited to announce the opening of our state-of-the-art STEM laboratory, equipped with the latest technology for hands-on learning.',
      image: 'https://images.pexels.com/photos/159751/science-test-lab-laboratory-159751.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'Facilities'
    },
    {
      date: '2024-01-05',
      title: 'Winter Concert Performance',
      excerpt: 'Our music students delivered an outstanding winter concert performance, showcasing months of dedicated practice and musical growth.',
      image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'Arts & Culture'
    },
    {
      date: '2023-12-20',
      title: 'Community Service Project Success',
      excerpt: 'Our students and families came together to support local families during the holiday season, demonstrating the spirit of giving and community service.',
      image: 'https://images.pexels.com/photos/6646917/pexels-photo-6646917.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'Community'
    }
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <section id="news" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Latest News</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Stay updated with the latest happenings, achievements, and events at The Prime Educate School.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {news.map((article, index) => (
            <article key={index} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
              <img 
                src={article.image} 
                alt={article.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-3 py-1 rounded-full">
                    {article.category}
                  </span>
                  <div className="flex items-center text-gray-500 text-sm">
                    <Calendar className="h-4 w-4 mr-1" />
                    {formatDate(article.date)}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{article.title}</h3>
                <p className="text-gray-600 mb-4 leading-relaxed">{article.excerpt}</p>
                <button className="text-blue-600 hover:text-blue-800 font-semibold flex items-center transition-colors">
                  Read More <ArrowRight className="h-4 w-4 ml-1" />
                </button>
              </div>
            </article>
          ))}
        </div>

        {/* Upcoming Events */}
        <div className="bg-white rounded-lg p-8 shadow-lg">
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Upcoming Events</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="border-l-4 border-blue-600 pl-4">
              <div className="text-blue-600 font-semibold text-sm mb-1">January 25, 2024</div>
              <h4 className="font-bold text-gray-900 mb-2">Parent-Teacher Conferences</h4>
              <p className="text-gray-600 text-sm">Schedule your meeting to discuss your child's progress</p>
            </div>
            <div className="border-l-4 border-green-600 pl-4">
              <div className="text-green-600 font-semibold text-sm mb-1">February 1, 2024</div>
              <h4 className="font-bold text-gray-900 mb-2">Open House</h4>
              <p className="text-gray-600 text-sm">Discover our school and meet our dedicated faculty</p>
            </div>
            <div className="border-l-4 border-yellow-600 pl-4">
              <div className="text-yellow-600 font-semibold text-sm mb-1">February 14, 2024</div>
              <h4 className="font-bold text-gray-900 mb-2">Spring Semester Registration</h4>
              <p className="text-gray-600 text-sm">Registration opens for spring semester courses</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default News;