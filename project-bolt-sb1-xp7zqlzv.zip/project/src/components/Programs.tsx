import React from 'react';
import { BookOpen, Calculator, Palette, Globe, Microscope, Music } from 'lucide-react';

const Programs = () => {
  const programs = [
    {
      icon: BookOpen,
      title: 'Language Arts',
      description: 'Comprehensive English literature and writing programs that develop critical thinking and communication skills.',
      features: ['Creative Writing', 'Literature Analysis', 'Public Speaking', 'Debate Club']
    },
    {
      icon: Calculator,
      title: 'Mathematics',
      description: 'Advanced mathematics curriculum from basic arithmetic to calculus, preparing students for STEM careers.',
      features: ['Algebra & Geometry', 'Statistics', 'Calculus', 'Math Olympics']
    },
    {
      icon: Microscope,
      title: 'Sciences',
      description: 'Hands-on science education covering biology, chemistry, physics, and environmental science.',
      features: ['Laboratory Work', 'Research Projects', 'Science Fair', 'Field Studies']
    },
    {
      icon: Globe,
      title: 'Social Studies',
      description: 'Understanding history, geography, civics, and cultures to develop global citizenship.',
      features: ['World History', 'Geography', 'Government', 'Cultural Studies']
    },
    {
      icon: Palette,
      title: 'Arts Program',
      description: 'Creative expression through visual arts, drama, and digital media production.',
      features: ['Drawing & Painting', 'Drama Club', 'Digital Art', 'Art Exhibitions']
    },
    {
      icon: Music,
      title: 'Music Education',
      description: 'Comprehensive music program including choir, band, and individual instrument instruction.',
      features: ['School Choir', 'Band Program', 'Piano Lessons', 'Music Theory']
    }
  ];

  return (
    <section id="programs" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Academic Programs</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our comprehensive curriculum is designed to challenge and inspire students across all disciplines, preparing them for success in higher education and beyond.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {programs.map((program, index) => {
            const IconComponent = program.icon;
            return (
              <div key={index} className="bg-gray-50 rounded-lg p-8 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <IconComponent className="h-12 w-12 text-blue-600 mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{program.title}</h3>
                <p className="text-gray-600 mb-6">{program.description}</p>
                <ul className="space-y-2">
                  {program.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-gray-700">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Additional Programs Section */}
        <div className="mt-16 bg-blue-600 rounded-lg p-8 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">Extracurricular Activities</h3>
          <p className="text-xl mb-6">
            Beyond academics, we offer a wide range of activities to help students discover their passions and develop leadership skills.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>Sports Teams</div>
            <div>Robotics Club</div>
            <div>Student Government</div>
            <div>Community Service</div>
            <div>Chess Club</div>
            <div>Photography Club</div>
            <div>Environmental Club</div>
            <div>Model UN</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Programs;